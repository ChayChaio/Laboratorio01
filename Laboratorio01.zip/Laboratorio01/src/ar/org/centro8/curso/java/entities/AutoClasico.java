package ar.org.centro8.curso.java.entities;


public class AutoClasico extends Auto{

    private Radio radio;
    
    public AutoClasico(String marca, String modelo, String color, double precio) {
        super(marca, modelo, color, precio);
    }

    public AutoClasico(String marca, String modelo, String color, double precio, String marcaRadio) {
        super(marca, modelo, color, precio);
        this.radio = radio;
    }

    
    @Override
    public String toString() {
        return "AutoClasico" + super.toString() + "\nRadio=" + radio ;
    }

    
    
    
}