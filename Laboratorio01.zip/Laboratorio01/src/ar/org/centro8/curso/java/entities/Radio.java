package ar.org.centro8.curso.java.entities;

public class Radio{
    
    private String marca;

    public Radio(String marca) {
        this.marca = marca;
    }
    
    public void setRadio(){
        this.marca=marca;
    }
    
    public String getRadio(String marca){
        return marca;
    }

    @Override
    public String toString() {
        return marca;
    }
    
    
    
}