package ar.org.centro8.curso.java.entities;

public abstract class Auto {

    private String marca;
    private String modelo;
    private String color;
    private double precio;
    private Radio radio;

    public Auto(String marca, String modelo, String color, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }
    
    public Auto(String marca, String modelo, String color, double precio, String marcaRadio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
        this.radio =new Radio(marcaRadio);
    }

    public double getPrecio() {
        return precio;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Radio getRadio() {
        return radio;
    }

    public void setRadio(String marcaRadio) {
        this.radio =new Radio (marcaRadio);
    }

    
    @Override
    public String toString() {
        return "Auto" + "\nmarca=" + marca + ", \nmodelo=" + modelo 
                + ", \ncolor=" + color + ", \nprecio=" + precio;
    }

    
   
}