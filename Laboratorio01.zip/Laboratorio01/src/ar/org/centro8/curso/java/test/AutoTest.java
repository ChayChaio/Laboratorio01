package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Radio;


public class AutoTest {

    public static void main(String[] args) {
        
        System.out.println("----AutoClasico1 con radio----");
        AutoClasico ac1=new AutoClasico("Fiat", "Uno", "Blanco", 20000, "Infinity");
        System.out.println(ac1.toString());
        
        System.out.println("----AutoClasico2 sin radio----");
        AutoClasico ac2=new AutoClasico("Peugeot", "404", "Verde", 150000);
        System.out.println(ac2.toString());
        
        System.out.println("----AutoClasico2 setRadio----");
        ac2.setRadio("Pioneer");
        System.out.println(ac2.toString());
        
        System.out.println("----AutoClasico3 sin radio----");
        AutoClasico ac3=new AutoClasico("Fiat", "Uno", "Blanco", 20000,null);
        System.out.println(ac3.toString());
        
        System.out.println("----AutoNuevo1----");
        AutoNuevo an1=new AutoNuevo("Ford", "Fiesta", "Rojo", 250000, "Stromberg");
        System.out.println(an1.toString());
        
    }
    
}