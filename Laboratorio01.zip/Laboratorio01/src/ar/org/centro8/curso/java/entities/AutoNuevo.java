package ar.org.centro8.curso.java.entities;

public class AutoNuevo extends Auto{

    private Radio radio;
    
    public AutoNuevo(String marca, String modelo, String color, double precio, String marcaRadio) {
        super(marca, modelo, color, precio, marcaRadio);
        this.radio=new Radio(marcaRadio);
    }

        
    @Override
    public String toString() {
        return "AutoNuevo" + super.toString() + "\nradio=" + radio;
    }

    
    
}