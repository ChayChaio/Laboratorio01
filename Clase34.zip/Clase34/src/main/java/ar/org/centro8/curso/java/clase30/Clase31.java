package ar.org.centro8.curso.java.clase30;
public class Clase31 {
    public static void main(String[] args) {
        /*
        
                Ciclo de vida de un Thread
        
        NEW
        Cuando ejecutamos el constructor new Thread()
        No se starteó
        
        RUNNABLE
        isAlive()=true;
        Cuando se ejecuta el método .start()
        
        BLOCKED
        No decidimos por usuario cuando se produce.
        Es un bloqueo por I/O (input/output)
        Está esperando información de disco o teclado.
        
        WAITING
        Es cuando está esperando algo.
        .sleep()
        .wait()
        
        TERMINATED
        Estado de muerto. Cuando el hilo muere.
        El hilo puede morir por dos causas:
        Muerte natural: Cuando el mp3 terminó de reproducir normalmente.
        Asesinato: Cuando se ejecuta el método .stop()
        
        */
        
        Thread t1 =new Thread(new HiloR("hilo1"));
        Thread t2 =new Thread(new HiloR("hilo2",800));
        Thread t3 =new Thread(new HiloR("hilo3",600));
        Thread t4 =new Thread(new HiloR("hilo4",400));
        
        System.out.println(t1.getState());
        
        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.NORM_PRIORITY);
        t3.setPriority(Thread.NORM_PRIORITY);
        t4.setPriority(Thread.MAX_PRIORITY);
        
        /*
        Results may vary.
        */
        
        //t1.start();
        //t2.start();
        //t3.start();
        //t4.start();
        //t1.start();       -- IllegalThreadException. No se puede volver a startear un hilo.
        System.out.println(t1.getState());
        
        // método join une el hilo principal al hilo en cuestión. Lo hace secuencial.
        // En este caso es al pedo. Sirve para darle un orden de ejecución al programa.
        try {
            t1.start();
            //t1.join();
            t2.start();
            //t2.join();
            t3.start();
            //t3.join();
            t4.start();
            //t4.join();
            
            t1.join();
            t2.join();
            t3.join();
            t4.join();
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //try {t1.sleep(11000);} catch(Exception e){}
        
        // método .yield no sirve para nada. (?)
        // Le cede el paso a otro hilo. (?)
        // Lo puso en HiloR
        
        
        // Synchronized
        
        System.out.println("Fin del programa");
        
        System.out.println(t1.getState());
        
    }
}
