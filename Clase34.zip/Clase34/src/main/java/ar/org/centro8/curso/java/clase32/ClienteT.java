package ar.org.centro8.curso.java.clase32;
public class ClienteT extends Thread{
    private String nombre;
    private Cuenta cuenta;

    public ClienteT(String nombre, Cuenta cuenta) {
        this.nombre = nombre;
        this.cuenta = cuenta;
    }

    @Override
    public void run() {
        cuenta.debitar(2000);
        System.out.println("Saldo: "+cuenta.getSaldo());
    }
    
    
}
