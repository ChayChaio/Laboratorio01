package ar.org.centro8.curso.java.clase34;
public class TCPApp {
    /*
            Protocolo TCP/IP:  Caro    Lento    Exacto
            Protocolo UDP:     Barato  Veloz   No Exacto
        
            
                    Protocolo TCP / IP
        
            Server                              Client
            -----------                         -----------
            new ServerSocket(int port);         new Socket(String ip, int port);
            .accept()
            -----------                         -----------
            OutputStream        -------->       InputStream
            InputStream         <--------       OutputStream
            -----------                         -----------
            .close()                            .close()
        
            BufferedInputStream - BufferedOutputStream: Stream de buffers. Buffer de Bytes.
            DataInputStream - DataOutpuStream:  Datos primitivos de java.
            ObjectOutputStream - ObjectInputStream: Objetos de Java
            
        */
}
