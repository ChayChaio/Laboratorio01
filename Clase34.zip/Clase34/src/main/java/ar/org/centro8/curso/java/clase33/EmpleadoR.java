package ar.org.centro8.curso.java.clase33;
public class EmpleadoR implements Runnable{
    String nombre;
    boolean esJefe;
    Saludo saludo;

    public EmpleadoR(String nombre, boolean esJefe, Saludo saludo) {
        this.nombre = nombre;
        this.esJefe = esJefe;
        this.saludo = saludo;
    }
    
    @Override
    public void run() {
        saludo.saludar(nombre, esJefe);
    }

}
