package ar.org.centro8.curso.java.clase32;
public class Cuenta {
    private double saldo = 2000;
    public void debitar(double monto){
        System.out.println("Iniciando operación débito");
        synchronized(this){         // Sincronizado parcial apareció en JDK 7 o sup
            if (saldo >= monto) {
                try {
                    Thread.sleep(2000);
                } catch (Exception e) {
                }
                saldo -= monto;
            } else {
                System.out.println("No hay fondos suficientes.");
            }
        }
        System.out.println("Operación debitar terminada");
    }
    
    public synchronized void depositar(double monto){
        this.saldo+=monto;
    }

    public synchronized double getSaldo() {
        return saldo;
    }
    
    
    
}
