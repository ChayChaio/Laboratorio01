package ar.org.centro8.curso.java.clase30;

public class HiloT extends Thread{

    private String nombre;
    
    public HiloT(String nombre){
        this.nombre=nombre;
    }

    @Override
    public void run() {
        // Este método puede ejecutarse en un nuevo hilo
        for (int i = 1; i <= 10; i++) {
            System.out.println(nombre+" "+i);
            try{Thread.sleep(1000);} catch (Exception e){System.out.println(e);}
        }
    }
    
    
    
}