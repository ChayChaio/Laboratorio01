package ar.org.centro8.curso.java.clase33;
public class SaludoApp {
    public static void main(String[] args) {
        
        Saludo saludo = new Saludo();
        
        EmpleadoR ana= new EmpleadoR("Ana", false, saludo);
        EmpleadoR luis= new EmpleadoR("Luis", false, saludo);
        EmpleadoR ivo= new EmpleadoR("Ivo", false, saludo);
        EmpleadoR maria= new EmpleadoR("Maria", false, saludo);
        EmpleadoR jefe= new EmpleadoR("Jefe", true, saludo);
        
        new Thread(ana).start();
        new Thread(luis).start();
        new Thread(ivo).start();
        new Thread(maria).start();
        try {Thread.sleep(500);} catch (Exception e) {}
        new Thread(jefe).start();
        
    }
}
