package ar.org.centro8.curso.java.clase30;

import java.text.DecimalFormat;
import javax.swing.JTextField;

public class CronometroR implements Runnable{
    private JTextField txt;
    //private int contador=0;
    private boolean correr=false;
    private int dias=00;
    private int horas=00;
    private int minutos=00;
    private int segundos=00;
    private static final DecimalFormat df = new DecimalFormat("00");
    
    public CronometroR(JTextField txt) {
        this.txt = txt;
    }
    
    @Override
    public void run() {
        while(true){
            if (correr){
                segundos++;
                if( segundos == 60 ){
                    segundos = 0;
                    minutos++;
		}
		if ( minutos == 60 ){
                    minutos = 0;
                    horas++;
                }
                if (horas == 24 ){
                    horas=0;
                    dias++;
                }

                txt.setText(df.format(dias)+":"+df.format(horas)+":"+df.format(minutos)+":"+df.format(segundos));
            }
            try { Thread.sleep(1000);} catch (Exception e) {}
        }
    }

    public void start(){
        correr=true;
    }
    
    public void pausa(){
        correr=false;
    }
    
    public void reset(){
        correr=false;
        txt.setText("00:00:00:00");
    }
    
}
