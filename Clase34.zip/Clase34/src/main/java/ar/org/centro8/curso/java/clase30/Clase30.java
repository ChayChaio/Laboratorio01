package ar.org.centro8.curso.java.clase30;

public class Clase30 {

    public static void main(String[] args) {
        
        /*
        
        Tarea 1: Leer el archivo 1 o DB1     medio 1                    10seg
        Tarea 2: Leer el archivo 2 o DB2     medio 2                    10seg
        Tarea 3: abrir un formulario y mostrar file 1 y file 2          1seg
          Tarea 1     Tarea 2   Tarea 3
        |----------|----------|-
            10s         10s     1s
        
        Total 21s
        
          Tarea 1
        |----------|
            10seg
          Tarea 2
        |----------|
            10seg
                     Tarea 3
                   |-|
                    1seg
        Total 11s
        
          Tarea 1
        |----------|
            10seg
          Tarea 2
        |----------|
            10seg
        Tarea 3
        |-|
        1seg
        Total 10s
        
        */
        
        //Clase Thread
        HiloT hiloT1=new HiloT("hiloT1");
        HiloT hiloT2=new HiloT("hiloT2");
        HiloT hiloT3=new HiloT("hiloT3");
        HiloT hiloT4=new HiloT("hiloT4");
        
        //método .run()
        //Al invocar este método se ejecuta en el hilo principal
        //hiloT1.run();
        //hiloT2.run();
        //hiloT3.run();
        //hiloT4.run();
        
        //HiloT.run() funciona de modo secuencial, no por hilos.
        
        //método .start()
        //Este método invoca al método .run() en un nuevo hilo.
        //hiloT1.start();
        //hiloT2.start();
        //hiloT3.start();
        //hiloT4.start();
        
        //Interfaz Runnable
        HiloR hiloR1=new HiloR("hiloR1");
        HiloR hiloR2=new HiloR("hiloR2");
        HiloR hiloR3=new HiloR("hiloR3");
        HiloR hiloR4=new HiloR("hiloR4");
        
        //Thread anonimo
        HiloR hiloR6=new HiloR("hiloR6");
        
        Thread t1=new Thread(hiloR1);
        Thread t2=new Thread(hiloR2);
        Thread t3=new Thread(hiloR3);
        Thread t4=new Thread(hiloR4);
        
        //Runnable anonimo
        Thread t5=new Thread(new HiloR("hiloR5"));
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        new Thread(hiloR6).start();
        //Runnable anonimo e hilo Anonimo
        new Thread(new HiloR("hiloR7")).start();
        
        
        
    }
    
}