package ar.org.centro8.curso.java.clase32;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class App {
    public static void main(String[] args) {
        Cuenta cuenta = new Cuenta();
        
        ClienteT c1 = new ClienteT("Ana", cuenta);
        
        ClienteT c2 = new ClienteT("Luis", cuenta);
        
        ClienteT empleador = new ClienteT("Jefe", cuenta);
        
        c1.start();
        c2.start();
        
        
        // Diferencias entre Hashtable y HashMap?
        /*
        Hashtable   (Legacy=delegado. Es obsoleta.)
            - Métodos sincronizados
            - MultiThread
            - Lento
        
        HashMap 
            - Métodos no sincronizados
            - No es multiThread
            - Veloz
        
        Clase Collections: Provee un factory collecciones parcialmente Synchronized
        */
        
        //Hashtable mapa = new Hashtable();       // Tiene métodos sincronizados
        //HashMap mapa = new HashMap();         // No tiene métodos sincronizados
        Map<String, String>mapa=Collections.synchronizedMap(new HashMap<String, String>());
        mapa.put("lu", "lunes");
        mapa.put("ma", "martes");
        mapa.put("mi", "miercoles");
        mapa.put("ju", "jueves");
        mapa.put("vi", "viernes");
        System.out.println(mapa.get("lu"));
        mapa.forEach((k, v)->System.out.println(k+" "+v));
        
    }
}
