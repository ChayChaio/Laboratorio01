package ar.org.centro8.curso.java.clase34;

import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        //String mensaje = "<h1>Servidor de Rosario</h1>";
        String mensaje = "Los odio a todos.";
        mensaje=    "HTTP/1.1 200 OK\n"+
                    "Contect-Type: text/plain\n"+
                    "Content-Length: "+mensaje.length()+"\n\n"
                    +mensaje;
        try ( ServerSocket ss = new ServerSocket(8000)) {
            while (true) {
                System.out.println("Esperando conexión del cliente...");
                try (
                         Socket so = ss.accept();  
                        OutputStream out = so.getOutputStream();
                ) {
                    System.out.println("Se conectó: " + so.getInetAddress());
                    out.write(mensaje.getBytes());
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
