package chat;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapaDirecciones {
    public static Map<String, String>getMapa(){
        Map<String, String>map=new LinkedHashMap();
        map.put("Rosario", "192.168.0.5");
        map.put("Rocio", "192.168.0.5");
        map.put("Chaio", "192.168.0.5");
        map.put("Chay", "192.168.0.5");
        return map;
    }
}
