package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Moto;
import ar.org.centro8.curso.java.entities.Vehiculo;
import java.text.DecimalFormat;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Set;

public class TestVehiculo {

    private static Set<Vehiculo> lista1= new LinkedHashSet();
    
    public static void main(String[] args) {
        
        cargar();
        
        Listado();
        
        separador();
        

       
        VehiculoMasCaro();
        
        System.out.println(" ");

        VehiculoMasBarato();
        
        System.out.println(" ");
        
        VehiculoModeloConY();
        
        
        separador();
        
        OrdenPrecioMayorAMenor();
        
        separador();
        
        VehiculosOrdenNatural();
        
    }

    private static void Listado() {
        lista1.forEach(System.out::println);
    }

    private static void VehiculosOrdenNatural() {
        System.out.println("Vehículos ordenados por orden natural:");
        
        lista1
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

    private static void OrdenPrecioMayorAMenor() {
        System.out.println("Vehículos ordenados por precio de mayor a menor: ");
        lista1
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca()+" "+v.getModelo()));
    }

    private static void VehiculoModeloConY() {
        /**
         * Consideramos que no hay más de un vehículo con la letra 'Y' dentro del modelo
         */
        DecimalFormat df=new DecimalFormat("#,###.00");
        lista1
                .stream()
                .filter(v->v.getModelo().toLowerCase().contains("y"))
                .forEach(v->System.out.println("Vehículo que contiene en el modelo la letra ‘Y’: "
                        +v.getMarca()+" "+v.getModelo()+" "+df.format(v.getPrecio())));
    }

    private static void VehiculoMasBarato() {
        /**
         * Consideramos que no hay más de un vehículo con el precio más barato
         */
        lista1
                .stream()
                .filter(p->p.getPrecio()==lista1
                        .stream()
                        .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio())
                .forEach(v->System.out.println("Vehículo de menor precio: "
                        + v.getMarca()+" "+v.getModelo()));
    }

    private static void VehiculoMasCaro() {
        /**
         * Consideramos que no hay más de un vehículo con el precio más caro
         */
        
        lista1
                .stream()
                .filter(p->p.getPrecio()==lista1
                        .stream()
                        .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                        .get()
                        .getPrecio())
                .forEach(v->System.out.println("Vehículo de mayor precio: "
                        + v.getMarca()+" "+v.getModelo()));
    }

    private static void separador() {
        System.out.println("============================");
    }
 
    public static void cargar(){
        lista1.add(new Auto(4, "Peugeot", "206", 200000.00));
        lista1.add(new Moto(125, "Honda", "Titan", 60000.00));
        lista1.add(new Auto(5, "Peugeot", "208", 250000.00));
        lista1.add(new Moto(160, "Yamaha", "YBR", 80500.50));
    }
    
}